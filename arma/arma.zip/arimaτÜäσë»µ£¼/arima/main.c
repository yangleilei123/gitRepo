//
//  main.c
//  arima
//
//  Created by 杨雷雷 on 2018/3/12.
//  Copyright © 2018年 yangleilei. All rights reserved.
//
#include  <stdio.h>
#include  <stdlib.h>
#include  <math.h>

double uniform(double a,double b,long int *seed)
{
    double t;
    *seed=2045*(*seed)+1;
    *seed=*seed-(*seed/1048576)*1048576;
    t=(*seed)/1048576.0;
    t=a+(b-a)*t;
    return(t);
}

double gauss(double mean,double sigma,long int *s)
{
    //double mean,sigma;
    //long int *s;
    int i;
    double x,y;
    for(x=0,i=0;i<12;i++)
        x+=uniform(0.0,1.0,s);
    x=x-6.0;
    y=mean+x*sigma;
    return(y);
}

void arma(double a,double b,int p,int q,double mean,double sigma,long int *seed,double x,int n)
{
    int n,p,q;
    long int *seed;
    double mean,sigma,a[],b[],x[];
    int i,j,m;
    double s,*w;
    w=malloc(n*sizeof(double));
    for(k=0;k<n;k++)
        w[k]=gauss(mean,sigma,seed);
    x[0]=b[0]*w[0];
    for(k=1;k<=p;k++)
    {
        s=0.0;
        for(i=1;i<=k;i++)
        {
            s+=a[i]*x[k-i];}
            s=b[0]*w[k]-s;
            if(q==0)
            {
                x[k]=s;
                continue;
            }
            m=(k>q)?q:k;
            for(i=1;i<=m;i++)
            {
                s+=b[i]*w[k-i];}
                x[k]=s;
            }
    
    
    for(k=(p+1);k<n;k++)
    {
        s=0.0;
        for(i=1;i<=p;i++)
        {s+=a[i]*x[k-i];}
        s=b[0]*w[k]-s;
        if(q==0)
        {x[k]=s;
            continue;
        }
        for(i=1;i<=q;i++)
        {s+=b[i]*w[k-i];}
        x[k]=s;
    }
    free(w);
}

int main(int argc, const char * argv[])
{
    int i,n,p,q;
    long seed;
    double mean,sigma,x[200];
    static double a[3]={1.0,1.45,0.6};
    static double b[3]={1.0,-0.2,-0.1};
    n=200;
    p=2;
    q=2;
    seed=135791;
    mean=0.0;
    sigma=0.5;
    arma(a,b,p,q,mean,sigma,&seed,x,n);
    for(i=1;i<32;i+=4)
    {
        printf("  %f     %f",x[i],x[i+1]);
        printf("  %f     %f",x[i+2],x[i+3]);
        printf("\n");
    }
}




